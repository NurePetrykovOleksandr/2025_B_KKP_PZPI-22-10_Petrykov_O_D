__title__ = 'Django Form Surveys'
__version__ = '2.5.0'
__author__ = 'irfanpule'
